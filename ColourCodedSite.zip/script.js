const today = new Date();
const dayIndex = today.getDay() % puzzles.length; // 0 = Sunday
const puzzle = puzzles[dayIndex];

document.getElementById("color-theme").textContent = `Theme: ${puzzle.color}`;
const cluesDiv = document.getElementById("clues");

puzzle.clues.forEach(clue => {
  const p = document.createElement("p");
  p.textContent = clue;
  cluesDiv.appendChild(p);
});

function checkAnswer() {
  const userGuess = document.getElementById("guess").value.trim().toLowerCase();
  const result = document.getElementById("result");
  if (userGuess === puzzle.answer.toLowerCase()) {
    result.textContent = "Correct!";
    result.style.color = "green";
  } else {
    result.textContent = "Try again.";
    result.style.color = "red";
  }
}
