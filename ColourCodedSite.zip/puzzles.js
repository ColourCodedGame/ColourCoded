const puzzles = [
  {
    color: "Red",
    clues: ["Fire", "Stop", "Rose"],
    answer: "red"
  },
  {
    color: "Orange",
    clues: ["Fruit", "Sunset", "Carrot"],
    answer: "orange"
  },
  {
    color: "Yellow",
    clues: ["Sun", "Lemon", "Taxi"],
    answer: "yellow"
  },
  {
    color: "Green",
    clues: ["Grass", "Emerald", "Go"],
    answer: "green"
  },
  {
    color: "Blue",
    clues: ["Sky", "Ocean", "Sapphire"],
    answer: "blue"
  },
  {
    color: "Purple",
    clues: ["Lavender", "Grape", "Royalty"],
    answer: "purple"
  },
  {
    color: "Pink",
    clues: ["Flamingo", "Bubblegum", "Blush"],
    answer: "pink"
  }
];
